 <!--map-modal -->
 <div class="map-modal-wrap">
     <div class="map-modal-wrap-overlay"></div>
     <div class="map-modal-item">
         <div class="map-modal-container fl-wrap">
             <div class="map-modal fl-wrap">
                 <div id="singleMap" data-latitude="40.7" data-longitude="-73.1"></div>
             </div>
             <h3><span>Location for : </span><a href="#">Listing Title</a></h3>
             <div class="map-modal-close"><i class="fal fa-times"></i></div>
         </div>
     </div>
 </div>
 <!--map-modal end -->